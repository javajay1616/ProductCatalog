Technologies used:
1. Java 8
2. Struts 2
3. HTML 5
4 CSS3
5. Apache tomcat 8.0
6. Eclipse Neon(Version: Neon.3 Release (4.6.3))
7. Java Script
8. jQuery1.12.0
9. datatable


Step 1:Import war file into Eclipse Neon and add tomcat 8.0 server
2. Run Code on Server
3. Login With user id "sam" and password "sam@123"

